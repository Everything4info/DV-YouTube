<?php
header('location: ../index');
?>
